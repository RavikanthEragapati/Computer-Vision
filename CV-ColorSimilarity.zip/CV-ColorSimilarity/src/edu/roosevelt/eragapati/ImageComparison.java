package edu.roosevelt.eragapati;

import java.awt.Color;

/**
 * @author eragapati
 *
 */

import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.imageio.ImageIO;

public class ImageComparison {

	BufferedImage img;
	int height, width;
	int value = 0;
	Map<String, List<List<Integer>>> histogram = new HashMap<String, List<List<Integer>>>();
	List<MyEntry> list = new ArrayList<MyEntry>();
	public void loadAndCompare() {
		String filename = null;
		try {
			File folder = new File("img/");
			String[] listOfFiles = folder.list();

			for (int i = 0; i < listOfFiles.length; i++) {
				filename = listOfFiles[i];
				img = ImageIO.read(new File("img/" + listOfFiles[i]));

				// getting rgb values for first image
				create3DHistogram(img, filename);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		// System.out.println(histogram);
	}

	private void create3DHistogram(BufferedImage img, String filename) {
		// TODO Auto-generated method stub
		width = img.getWidth();
		height = img.getHeight();
		List<List<Integer>> index = new ArrayList<List<Integer>>();
		for (int i = 0; i < width; i++) {
			for (int j = 0; j < height; j++) {
				List<Integer> rgbValues = new ArrayList<Integer>();
				Color c = new Color(img.getRGB(i, j));

				int red = c.getRed();
				int blue = c.getBlue();
				int green = c.getGreen();

				rgbValues.add(red);
				rgbValues.add(green);
				rgbValues.add(blue);
				index.add(rgbValues);
			}
		}
		histogram.put(filename, index);
	}

	public static void main(String[] arg) {
		ImageComparison IC = new ImageComparison();
		IC.loadAndCompare();
		IC.compare();
		IC.output();
	}

	private void output() {
		// TODO Auto-generated method stub
		int temp, temp1;
		String str = null,str1 = null;
		List<String> match = new ArrayList<String>();
		List<String> mismatch = new ArrayList<String>();
		
			if(!list.isEmpty())
			{
				//**************************1st image***********************
				for(int j=0;j<=551;j=j+23){
				temp = list.get(0).value;
				for(int i = j+1;i<=j+22 && i<=551;i++)
				{
					if(list.get(i).value <= temp)
					{
						temp = list.get(i).value;
						str = list.get(i).valueFor;
					}
			}
				match.add(str+" are similar\n");
				}
		}
			System.out.println(match);
	System.out.println("/**********************************************************************/");
			if(!list.isEmpty())
			{
				//**************************1st image***********************
				for(int j=0;j<=551;j=j+23){
				temp1 = list.get(0).value;
				for(int i = j+1;i<=j+22 && i<=551;i++)
				{
					if(list.get(i).value >= temp1)
					{
						temp1 = list.get(i).value;
						str1 = list.get(i).valueFor;
					}
			}
				mismatch.add(str1+" are different\n");
				}
		}
			System.out.println(mismatch);
	}

	private void compare() {
		// TODO Auto-generated method stub
		Set keyset = histogram.keySet();
		System.out.println(keyset);
		String imageA = null;
		String imageB = null;
		for (int i = 1; i <= 24; i++) {
			for (int j = 1; j <= 24; j++) {
				if (i <= 9) {
					imageA = "i0" + i + ".jpg";
				} else if (i > 9) {
					imageA = "i" + i + ".jpg";
				}
				if (j <= 9) {
					imageB = "i0" + j + ".jpg";
				} else if (j > 9) {
					imageB = "i" + j + ".jpg";
				}

				if (imageA.compareTo(imageB) != 0) {
					for (int k = 0; k <= 5309; k++) {
						for (int l = 0; l <= 2; l++) {
							// System.out.println(histogram.get(imageA).get(i).get(j));
							value = value + (histogram.get(imageA).get(k).get(l) - histogram.get(imageB).get(k).get(l));
						}
					}
				//	System.out.println("comp value between " + imageA + " and " + imageB + " is: " + Math.abs(value));
					MyEntry me = new MyEntry();
					me.value = Math.abs(value);
					me.valueFor = imageA+" and "+imageB;
					//if(list.isEmpty())
					list.add(me);
				/*	else if(list.get(0).value >= Math.abs(value)){
						list.get(0).value = Math.abs(value);
						list.get(0).valueFor = imageA+" and "+imageB;
					}*/
					value = 0;

				} else if (imageA.compareTo(imageB) == 0) {
					// do nothing
				}
			}
		}
	//	for(int z = 0; z<list.size();z++)
	//	System.out.println(list.get(z).value + " : "+list.get(z).valueFor);
	}
}