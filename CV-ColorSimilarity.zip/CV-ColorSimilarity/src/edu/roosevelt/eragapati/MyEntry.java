package edu.roosevelt.eragapati;

public class MyEntry {
int value;
String valueFor;
}
