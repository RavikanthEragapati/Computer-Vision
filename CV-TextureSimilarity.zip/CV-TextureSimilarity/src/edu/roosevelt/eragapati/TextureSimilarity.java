package edu.roosevelt.eragapati;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.imageio.ImageIO;

public class TextureSimilarity {
	BufferedImage img;
	int height, width;
	int value = 0;
	Map<String, List<Integer>> histogram = new HashMap<String, List<Integer>>();
	List<Entry> list = new ArrayList<Entry>();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TextureSimilarity texture = new TextureSimilarity();
		texture.loadImages();
		texture.compare();
		texture.output();
	}

	public void loadImages() {
		String filename = null;
		try {
			File folder = new File("img/");
			String[] listOfFiles = folder.list();

			for (int i = 0; i < listOfFiles.length; i++) {
				filename = listOfFiles[i];
				img = ImageIO.read(new File("img/" + listOfFiles[i]));

				// getting rgb values for first image
				createHistogram(img, filename);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		// System.out.println(histogram);
	}

	private void createHistogram(BufferedImage img, String filename) {
		int neighbor1, neighbor2, neighbor3, neighbor4, neighbor5, neighbor6, neighbor7, neighbor8;
		// TODO Auto-generated method stub
		width = img.getWidth();
		height = img.getHeight();

		List<Integer> grayValue = new ArrayList<Integer>();
		for (int i = -1; i <= width; i++) {
			for (int j = -1; j <= height; j++) {
				if (i == -1 && j == -1)
					grayValue.add(0);
				else if (i == -1 || j == -1)
					grayValue.add(0);
				else if (i == width || j == height)
					grayValue.add(0);
				else {
					if (i > -1 && i < width)
						if (j > -1 && j < height) {
							
							Color c1 = new Color(img.getRGB(i, j));

							if ((i - 1) < 0 || (j - 1) < 0)
								neighbor1 = 0;
							else {
								Color c = new Color(img.getRGB(i - 1, j - 1));
								neighbor1 = (c.getBlue() + c.getGreen() + c.getRed()) / 3;
							}
							// ****************************************************
							if ((i - 1 < 0) || j < 0)
								neighbor2 = 0;
							else {
								Color c = new Color(img.getRGB(i - 1, j));
								neighbor2 = (c.getBlue() + c.getGreen() + c.getRed()) / 3;
							}
							// ****************************************************
							if ((i - 1) < 0 || (j + 1) >= height)
								neighbor3 = 0;
							else {
								Color c = new Color(img.getRGB(i - 1, j + 1));
								neighbor3 = (c.getBlue() + c.getGreen() + c.getRed()) / 3;
							}
							// ****************************************************
							if ((i < 0) || (j - 1) < 0)
								neighbor4 = 0;
							else {
								Color c = new Color(img.getRGB(i, j - 1));
								neighbor4 = (c.getBlue() + c.getGreen() + c.getRed()) / 3;
							}
							// ****************************************************
							if (i < 0 || (j + 1) >= height)
								neighbor5 = 0;
							else {
								Color c = new Color(img.getRGB(i, j + 1));
								neighbor5 = (c.getBlue() + c.getGreen() + c.getRed()) / 3;
							}
							// ****************************************************
							if ((i + 1 >= width) || j - 1 < 0)
								neighbor6 = 0;
							else {
								Color c = new Color(img.getRGB(i + 1, j - 1));
								neighbor6 = (c.getBlue() + c.getGreen() + c.getRed()) / 3;
							}
							// ****************************************************
							if ((i + 1) >= width || j < 0)
								neighbor7 = 0;
							else {
								Color c = new Color(img.getRGB(i + 1, j));
								neighbor7 = (c.getBlue() + c.getGreen() + c.getRed()) / 3;
							}
							// ****************************************************
							if (((i + 1) <= width) || (j + 1) <= height)
								neighbor8 = 0;
							else {
								Color c = new Color(img.getRGB(i + 1, j + 1));
								neighbor8 = (c.getBlue() + c.getGreen() + c.getRed()) / 3;
							}
							// ****************************************************

							int neighbor = neighbor1 + neighbor2 + neighbor3 + neighbor4 + neighbor5 + neighbor6
									+ neighbor7 + neighbor8;
							int avg_RGB = ((((c1.getRed() + c1.getBlue() + c1.getGreen()) / 3) * 8) - neighbor)+2040;

							grayValue.add(avg_RGB);
						}
				}
			}
		}
		histogram.put(filename, grayValue);

	}
	private void compare() {
		// TODO Auto-generated method stub
		Set keyset = histogram.keySet();
	//	System.out.println(keyset);
		String imageA = null;
		String imageB = null;
		for (int i = 1; i <= 24; i++) {
			for (int j = 1; j <= 24; j++) {
				if (i <= 9) {
					imageA = "i0" + i + ".jpg";
				} else if (i > 9) {
					imageA = "i" + i + ".jpg";
				}
				if (j <= 9) {
					imageB = "i0" + j + ".jpg";
				} else if (j > 9) {
					imageB = "i" + j + ".jpg";
				}

				if (imageA.compareTo(imageB) != 0) {
					for (int k = 0; k <= 5703; k++) {
							// System.out.println(histogram.get(imageA).get(i).get(j));
							value = value + (histogram.get(imageA).get(k) - histogram.get(imageB).get(k));
					}
				//	System.out.println("comp value between " + imageA + " and " + imageB + " is: " + Math.abs(value));
					Entry me = new Entry();
					me.value = Math.abs(value);
					me.valueFor = imageA+" and "+imageB;
					//if(list.isEmpty())
					list.add(me);
				/*	else if(list.get(0).value >= Math.abs(value)){
						list.get(0).value = Math.abs(value);
						list.get(0).valueFor = imageA+" and "+imageB;
					}*/
					value = 0;

				} else if (imageA.compareTo(imageB) == 0) {
					// do nothing
				}
			}
		}
	//	for(int z = 0; z<list.size();z++)
	//	System.out.println(list.get(z).value + " : "+list.get(z).valueFor);
	}


	private void output() {
		// TODO Auto-generated method stub
		int temp, temp1;
		String str = null,str1 = null;
		List<String> match = new ArrayList<String>();
		List<String> mismatch = new ArrayList<String>();
		
			if(!list.isEmpty())
			{
				//**************************1st image***********************
				for(int j=0;j<=551;j=j+23){
				temp = list.get(0).value;
				for(int i = j+1;i<=j+22 && i<=551;i++)
				{
					if(list.get(i).value <= temp)
					{
						temp = list.get(i).value;
						str = list.get(i).valueFor;
					}
			}
				match.add(str+" are similar\n");
				}
		}
			System.out.println(match);
	System.out.println("/**********************************************************************/");
			if(!list.isEmpty())
			{
				//**************************1st image***********************
				for(int j=0;j<=551;j=j+23){
				temp1 = list.get(0).value;
				for(int i = j+1;i<=j+22 && i<=551;i++)
				{
					if(list.get(i).value >= temp1)
					{
						temp1 = list.get(i).value;
						str1 = list.get(i).valueFor;
					}
			}
				mismatch.add(str1+" are different\n");
				}
		}
			System.out.println(mismatch);
		//	System.out.println(histogram.get("i04.jpg"));

	}

	
}
