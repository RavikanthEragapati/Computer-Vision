package edu.roosevelt.eragapati;

public class Entry {
	int value;
	String valueFor;
}
